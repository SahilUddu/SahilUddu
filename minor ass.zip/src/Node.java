package com.DSAMINORPROJECT;
import java.util.Scanner;
public class Node {
    Node link;
    int info;
}
