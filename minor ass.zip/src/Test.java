package com.DSAMINORPROJECT;
import java.util.Scanner;
public class Test {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        SinglyLinkedList ob=new SinglyLinkedList();
        ob.create();
        while (true){
            System.out.println("******MENU******");
            System.out.println("1.Display the Linked List.");
            System.out.println("2.Find 2nd largest element.");
            System.out.println("3.Display reference of an element.");
            System.out.println("4.Remove Duplicate.");
            System.out.println("5.Count unique elements.");
            System.out.println("0.Exit");
            System.out.print("Enter the operation:");
            int op=sc.nextInt();
            switch (op){
                case 0:return;
                case 1:ob.display();
                       break;
                case 2:if(ob.find2ndMax()==Integer.MIN_VALUE)
                          System.out.println("2nd largest element doesn't exist.");
                       else
                          System.out.println("2nd largest element :"+ob.find2ndMax());
                       break;
                case 3:ob.displayReference();
                       break;
                case 4:ob.removeDuplicate();
                       break;
                case 5:System.out.println("Unique elements in Linked List:"+ob.countUnique());
                       break;
            }
        }
    }
}
