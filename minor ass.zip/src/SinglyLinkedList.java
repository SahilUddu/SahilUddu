package com.DSAMINORPROJECT;
import java.util.Scanner;
public class SinglyLinkedList {
    Node head,tail;
    Scanner sc=new Scanner(System.in);
    int count(){
        int c=0;
        Node curr=head;
        while (curr!=null){
            c++;
            curr=curr.link;
        }
        return c;
    }
    void create(){
        System.out.print("Do you want to add node(1/0):");
        int op=sc.nextInt();
        while (op!=0){
            System.out.print("Enter node value:");
            int val=sc.nextInt();
            System.out.print("Enter the index at which node is to inserted:");
            int ind=sc.nextInt();
            if(ind>=0&&ind<=count()){
                Node toAdd=new Node();
                toAdd.info=val;
                if(head==null){
                    head=toAdd;
                    tail=toAdd;
                }else{
                    if(ind==0){
                        toAdd.link=head;
                        head=toAdd;
                    }else if(ind==count()){
                        tail.link=toAdd;
                        tail=toAdd;
                        tail.link=null;
                    }else{
                        Node curr=head;
                        for(int i=0;i<ind-1;i++)
                            curr=curr.link;
                        toAdd.link=curr.link;
                        curr.link=toAdd;
                    }
                }
            }else{
                System.out.println("Wrong index entered.");
            }
            System.out.print("Do you want to add node(1/0):");
            op=sc.nextInt();
        }
    }
    void display(){
        if(head==null)
            System.out.println("Linked List is empty.");
        else{
            Node curr=head;
            System.out.print("Linked List:");
            while (curr!=null){
                System.out.print(curr.info+" ");
                curr=curr.link;
            }
            System.out.println();
        }
    }
    int find2ndMax(){
        int first,second;
        first=second=Integer.MIN_VALUE;
        Node curr=head;
        while (curr!=null){
            if(curr.info>first){
                second=first;
                first=curr.info;
            }else if(curr.info>second&&curr.info<first)
                second=curr.info;
            curr=curr.link;
        }
        return second;
    }
    void displayReference(){
        if(head==null)
            System.out.println("Linked List is empty.");
        else{
            System.out.print("Enter the element:");
            int ele=sc.nextInt();
            System.out.println("Reference of "+ele+"->");
            Node curr=head;
            boolean found=false;
            while (curr!=null){
                if(curr.info==ele){
                    found=true;
                    System.out.println(curr);
                }
                curr=curr.link;
            }
            if(!found)
                System.out.println(ele+" doesn't exist in the Linked List.");
        }
    }
    void removeDuplicate(){
        Node curr1,curr2;
        curr1=head;
        while (curr1!=null&& curr1.link!=null){
            curr2=curr1;
            while (curr2.link!=null){
                if(curr1.info==curr2.link.info)
                    curr2.link=curr2.link.link;
                else
                    curr2=curr2.link;
            }
            curr1=curr1.link;
        }
    }
    int countUnique(){
        int c=0;
        Node curr1,curr2;
        curr1=head;
        boolean found;
        while (curr1!=null){
            curr2=head;
            found=false;
            while (curr2!=null){
                if(curr1!=curr2&&curr1.info== curr2.info){
                    found=true;
                    break;
                }
                curr2= curr2.link;
            }
            if(!found)
                c++;
            curr1=curr1.link;
        }
        return c;
    }
}
